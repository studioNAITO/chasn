# chasn

### install
```shell
sh chasn.sh install
```

### Usage
 > When using `sdkmanager` or `android`, please do not install build-tools/tools. it will break. :(
